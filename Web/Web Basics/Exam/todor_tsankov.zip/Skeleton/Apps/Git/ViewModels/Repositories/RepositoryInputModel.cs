﻿namespace Git.ViewModels.Repositories
{
    public class RepositoryInputModel
    {
        public string Name { get; set; }

        public string RepositoryType { get; set; }
    }
}

﻿namespace SUS.MvcFramework
{
    public enum IdentityRole
    {
        User = 1,
        Admin = 2,
    }
}

﻿using System;

namespace P05FootballTeamGenerator
{
    public class StartUp
    {
        static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}

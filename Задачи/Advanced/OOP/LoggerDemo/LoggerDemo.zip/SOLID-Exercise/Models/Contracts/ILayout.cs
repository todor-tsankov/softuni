﻿namespace SOLID_Exercise.Models.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}

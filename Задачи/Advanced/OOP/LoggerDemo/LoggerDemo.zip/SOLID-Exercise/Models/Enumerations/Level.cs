﻿namespace SOLID_Exercise.Models.Enumerations
{
    public enum Level
    {
        Info = 0,
        Warning = 1,
        Error = 2,
        Critical = 3,
        Fatal = 4
    }
}

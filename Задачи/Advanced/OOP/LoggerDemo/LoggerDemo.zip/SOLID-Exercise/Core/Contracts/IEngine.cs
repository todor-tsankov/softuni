﻿namespace SOLID_Exercise.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}

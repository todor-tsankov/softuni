﻿using System;

namespace Shapes
{
    public class StartUp
    {
        static void Main()
        {
            var circle = new Circle(5);

            Console.WriteLine();
            Console.WriteLine(circle.Draw());
        }
    }
}

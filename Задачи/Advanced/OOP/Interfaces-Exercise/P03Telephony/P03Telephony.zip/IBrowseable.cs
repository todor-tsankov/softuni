﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03Telephony
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}

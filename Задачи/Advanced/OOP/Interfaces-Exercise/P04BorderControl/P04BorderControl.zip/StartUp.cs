﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main()
        {
            var enterCityList = ReadEntryList();
            var fakeIdLastDigits = Console.ReadLine();

            enterCityList.Select(x => x.Id)
                         .Where(i => i.EndsWith(fakeIdLastDigits))
                         .ToList()
                         .ForEach(Console.WriteLine);
        }

        private static List<IIdentifiable> ReadEntryList()
        {
            List<IIdentifiable> enterCityList = new List<IIdentifiable>();

            while (true)
            {
                var command = Console.ReadLine();

                if (command == "End")
                {
                    break;
                }

                var commandArgs = command.Split(" ", StringSplitOptions.RemoveEmptyEntries)
                                         .ToArray();

                IIdentifiable current = null;

                if (commandArgs.Length == 3)
                {
                    var name = commandArgs[0];
                    var age = int.Parse(commandArgs[1]);
                    var id = commandArgs[2];

                    current = new Citizen(id, name, age);
                }
                else if (commandArgs.Length == 2)
                {
                    var model = commandArgs[0];
                    var id = commandArgs[1];

                    current = new Robot(id, model);
                }

                if (current != null)
                {
                    enterCityList.Add(current);
                }
            }

            return enterCityList;
        }
    }
}

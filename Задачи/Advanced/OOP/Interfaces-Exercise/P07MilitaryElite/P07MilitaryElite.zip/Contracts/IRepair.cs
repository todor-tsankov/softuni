﻿namespace MilitaryElite.Contracts
{
    public interface IRepair
    {
        string Name { get; }
        int HoursWorked { get; }

        string ToString();
    }
}

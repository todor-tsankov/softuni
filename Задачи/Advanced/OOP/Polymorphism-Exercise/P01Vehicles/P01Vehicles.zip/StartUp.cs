﻿using System;
using System.Linq;

namespace Vehicles
{
    public class StartUp
    {
        static void Main()
        {
            var car = CreateVehicle();
            var truck = CreateVehicle();

            var n = int.Parse(Console.ReadLine());

            ExecuteCommands(car, truck, n);

            Console.WriteLine(car);
            Console.WriteLine(truck);
        }

        private static Vehicle CreateVehicle()
        {
            var vehicleInfo = ReadInputLine();

            var type = vehicleInfo[0];

            var vehicleFuelQuantity = double.Parse(vehicleInfo[1]);
            var vehicleFuelConsumption = double.Parse(vehicleInfo[2]);

            if (type == "Car")
            {
                return new Car(vehicleFuelQuantity, vehicleFuelConsumption);
            }
            else
            {
                return new Truck(vehicleFuelQuantity, vehicleFuelConsumption);
            }
        }
        private static void ExecuteCommands(Vehicle car, Vehicle truck, int n)
        {
            for (int i = 0; i < n; i++)
            {
                var command = ReadInputLine();

                var type = command[0];
                var vehicleType = command[1];
                var amount = double.Parse(command[2]);

                try
                {
                    ExecuteCommand(car, truck, type, vehicleType, amount);

                    if (type == "Drive")
                    {
                        Console.WriteLine($"{vehicleType} travelled {amount} km");
                    }
                }
                catch (InvalidOperationException ioe)
                {
                    Console.WriteLine(ioe.Message);
                }
            }
        }

        private static void ExecuteCommand(Vehicle car, Vehicle truck, string type, string vehicleType, double amount)
        {
            if (type == "Drive")
            {
                if (vehicleType == "Car")
                {
                    car.Drive(amount);
                }
                else if (vehicleType == "Truck")
                {
                    truck.Drive(amount);
                }
            }
            else if (type == "Refuel")
            {
                if (vehicleType == "Car")
                {
                    car.Refuel(amount);
                }
                else if (vehicleType == "Truck")
                {
                    truck.Refuel(amount);
                }
            }
        }

        private static string[] ReadInputLine()
        {
            return Console.ReadLine()
                          .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                          .ToArray();
        }
    }
}

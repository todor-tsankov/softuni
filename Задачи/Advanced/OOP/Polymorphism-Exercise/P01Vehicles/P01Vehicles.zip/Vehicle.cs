﻿using System;

namespace Vehicles
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;

        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity
        {
            get
            {
                return this.fuelQuantity;
            }
            protected set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }

                this.fuelQuantity = value;
            }
        }

        public double FuelConsumption
        {
            get
            {
                return this.fuelConsumption;
            }
            protected set
            {
                if (value <= 0)
                {
                    throw new ArgumentException();
                }

                this.fuelConsumption = value;
            }
        }

        public virtual void Drive(double distance)
        {
            var neededFuel = distance * this.FuelConsumption;

            if (neededFuel > this.FuelQuantity)
            {
                throw new InvalidOperationException();
            }

            this.FuelQuantity -= neededFuel;
        }

        public abstract void Refuel(double litres);
    }
}

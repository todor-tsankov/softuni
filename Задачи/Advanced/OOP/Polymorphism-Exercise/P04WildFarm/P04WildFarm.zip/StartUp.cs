﻿using P04WildFarm.Core;

namespace P04WildFarm
{
    public class StartUp
    {
        static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}

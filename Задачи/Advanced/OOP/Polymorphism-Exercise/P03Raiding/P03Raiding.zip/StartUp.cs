﻿using P03Raiding.Core;

namespace P03Raiding
{
    public class StartUp
    {
        static void Main()
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04HotelReservation
{
    public enum Season
    {
        Autumn = 1,
        Spring = 2,
        Winter = 3,
        Summer = 4
    }
}

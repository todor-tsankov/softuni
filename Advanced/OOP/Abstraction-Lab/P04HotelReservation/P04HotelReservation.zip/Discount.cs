﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04HotelReservation
{
    public enum Discount
    {
        None = 0,
        SecondTime = 10,
        VIP = 20
    }
}

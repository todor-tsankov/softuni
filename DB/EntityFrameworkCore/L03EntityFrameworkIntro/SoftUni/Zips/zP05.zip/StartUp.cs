﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static void Main()
        {
            var db = new SoftUniContext();

          //var employeesInfoStr = GetEmployeesFullInformation(db);
          //var employeesInfoStr = GetEmployeesWithSalaryOver50000(db);
            var employeesInfoStr = GetEmployeesFromResearchAndDevelopment(db);

            Console.WriteLine(employeesInfoStr);
        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var employees = context.Employees.Select(e => new { e.EmployeeId, e.FirstName, e.LastName, e.MiddleName, e.JobTitle, e.Salary })
                                             .OrderBy(e => e.EmployeeId)
                                             .ToList();

            var sb = new StringBuilder();

            foreach (var e in employees)
            {
                sb.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:F2}");
            }

            return sb.ToString()
                     .TrimEnd();
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var employees = context.Employees.Where(e => e.Salary > 50000)
                                             .Select(e => new { e.FirstName, e.Salary })
                                             .OrderBy(e => e.FirstName)
                                             .ToList();

            var sb = new StringBuilder();

            employees.ForEach(e => sb.AppendLine($"{e.FirstName} - {e.Salary:F2}"));

            return sb.ToString()
                     .TrimEnd();
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var employees = context.Employees.Select(e => new { e.FirstName, e.LastName, e.Department.Name, e.Salary })
                                             .Where(e => e.Name == "Research and Development")
                                             .OrderBy(e => e.Salary)
                                             .ThenByDescending(e => e.LastName)
                                             .ToList();

            var sb = new StringBuilder();

            employees.ForEach(e => sb.AppendLine($"{e.FirstName} {e.LastName} from {e.Name} - ${e.Salary:F2}"));

            return sb.ToString()
                     .TrimEnd();
        }
    }
}

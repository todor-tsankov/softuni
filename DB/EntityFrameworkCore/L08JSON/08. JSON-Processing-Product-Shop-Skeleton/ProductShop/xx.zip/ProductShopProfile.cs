﻿using AutoMapper;
using ProductShop.DTOs;
using ProductShop.Models;
using System.Collections.Generic;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            CreateMap<List<UserDTO>, UsersProductsDTO>()
                .ForMember(x => x.Users, y => y.MapFrom(z => z));

            CreateMap<User, UserDTO>();

        }
    }
}

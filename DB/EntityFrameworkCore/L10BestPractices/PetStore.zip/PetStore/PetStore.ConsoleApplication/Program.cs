﻿namespace PetStore.ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
